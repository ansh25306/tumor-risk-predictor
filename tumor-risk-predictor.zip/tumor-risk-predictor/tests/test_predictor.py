"""Unit tests for model loading, validation and inference (run: python -m unittest)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import predictor  # noqa: E402


class PredictorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model, cls.meta = predictor.load_artifacts()
        cls.benign = cls.meta["examples"]["Typical benign profile"]
        cls.malignant = cls.meta["examples"]["Typical malignant profile"]

    # --- model behaviour -------------------------------------------------
    def test_typical_profiles_are_classified_correctly(self):
        self.assertEqual(predictor.predict(self.model, self.meta, self.benign).label, "Benign")
        self.assertEqual(predictor.predict(self.model, self.meta, self.malignant).label, "Malignant")

    def test_probabilities_sum_to_one(self):
        pred = predictor.predict(self.model, self.meta, self.malignant)
        self.assertAlmostEqual(sum(pred.probabilities.values()), 1.0, places=9)
        self.assertGreater(pred.probability_malignant, 0.5)

    def test_numeric_strings_are_accepted(self):
        as_strings = {k: str(v) for k, v in self.benign.items()}
        self.assertEqual(predictor.predict(self.model, self.meta, as_strings).label, "Benign")

    def test_contributions_cover_all_features(self):
        df = predictor.contributions(self.model, self.meta, self.malignant)
        self.assertEqual(len(df), len(self.meta["features"]))

    # --- validation ------------------------------------------------------
    def test_missing_fields_are_all_reported(self):
        partial = dict(self.benign)
        partial.pop("mean_radius")
        partial["mean_area"] = None
        partial["mean_texture"] = "  "
        with self.assertRaises(predictor.ValidationError) as ctx:
            predictor.predict(self.model, self.meta, partial)
        self.assertEqual(len(ctx.exception.errors), 3)

    def test_invalid_values_are_rejected(self):
        for bad in ["abc", float("nan"), float("inf"), -1, True, 1e9]:
            with self.subTest(bad=bad):
                record = dict(self.benign, mean_radius=bad)
                with self.assertRaises(predictor.ValidationError):
                    predictor.predict(self.model, self.meta, record)

    def test_out_of_range_value_warns_but_predicts(self):
        feat = next(f for f in self.meta["features"] if f["key"] == "mean_radius")
        record = dict(self.benign, mean_radius=feat["max"] * 1.5)
        pred = predictor.predict(self.model, self.meta, record)
        self.assertEqual(len(pred.warnings), 1)

    # --- batch -----------------------------------------------------------
    def test_batch_flags_bad_rows_without_aborting(self):
        df = pd.DataFrame([self.benign, self.malignant, dict(self.benign, mean_radius=-5)])
        out = predictor.predict_dataframe(self.model, self.meta, df)
        self.assertEqual(list(out["prediction"].iloc[:2]), ["Benign", "Malignant"])
        self.assertTrue(pd.isna(out["prediction"].iloc[2]))
        self.assertIn("negative", out["note"].iloc[2])

    def test_batch_file_level_errors(self):
        with self.assertRaises(predictor.ValidationError):
            predictor.predict_dataframe(self.model, self.meta, pd.DataFrame())
        with self.assertRaises(predictor.ValidationError):
            predictor.predict_dataframe(self.model, self.meta, pd.DataFrame([{"mean_radius": 1}]))

    # --- artifacts -------------------------------------------------------
    def test_missing_artifacts_raise_readable_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(predictor.ModelLoadError) as ctx:
                predictor.load_artifacts(tmp)
            self.assertIn("train.py", str(ctx.exception))

    def test_corrupt_model_raises_readable_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "model.joblib").write_bytes(b"not a model")
            (Path(tmp) / "metadata.json").write_text(json.dumps({}))
            with self.assertRaises(predictor.ModelLoadError):
                predictor.load_artifacts(tmp)


if __name__ == "__main__":
    unittest.main()
